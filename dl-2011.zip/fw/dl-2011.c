#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>



#include "ffft.h"		/* Defs for using Fixed-point FFT module */
#include "mydefs.h"

#include "useful.h"

#ifdef debug
#include "uart.h"		// include uart function library
#include "rprintf.h"	// include printf function library
#include "vt100.h"		// include VT100 terminal support
#endif

/* PortB */
#define C3G_PB      BIT0
#define PWM_PB		BIT1
#define C3R_PB      BIT2
#define LED_PB      BIT3
#define B4_FREE_PB  BIT4
#define B5_FREE_PB  BIT5
#define B6_OSC      BIT6
#define B7_OSC      BIT7

/* PortC */

#define MODE_PC 	BIT0
#define AIN_PC	 	BIT1
#define C3B_PC      BIT2
#define C2G_PC      BIT3
#define C2R_PC      BIT4
#define C2B_PC      BIT5

/* PortD */

#define D0_FREE_PD  BIT0
#define D1_FREE_PD  BIT1

#define C1R_PD      BIT3
#define C1B_PD      BIT4
#define C1G_PD      BIT2

#define C4G_PD      BIT5
#define C4R_PD      BIT6
#define C4B_PD      BIT7


/*
#define DF_MISO_PB   BIT4
now instead
	DDRB &= ~(1<<DF_MISO_PB);
do
	DDRB &= ~DF_MISO_PB;

#define LED_PB BIT1
	PORTB |= LED_PB; 
*/

#define FFT_N 128

volatile uint8_t flags;
#define ADC_CYCLE           0
#define SILENCE             1
#define MODE_INPUT          2


#define CHANNEL_MAX 16
#define OUTPUT_MAX 12


struct 
{
//#ifdef debug
    union 
    {
//#endif
        int16_t samples[FFT_N];		  //Sampling buffer is 256 bytes!
        uint16_t spectrum [FFT_N/2];   //Spectrum bar length
//#ifdef debug
    };
//#endif
    complex_t bfly_buff[FFT_N];	  //Butterfly operation table, Waveform buffer is 512 bytes!
} mem;

uint8_t levels[CHANNEL_MAX];
uint8_t pwm_output[OUTPUT_MAX];
uint8_t output_buff[OUTPUT_MAX];


volatile uint16 tick; // system tick, increments every 1mS
uint8_t aru;
volatile uint8_t mode;
volatile uint8_t pwmpoint;
uint8_t samplesIndex;
volatile uint8_t pause;
uint8_t pause_cnt;
volatile uint8_t white_point;

uint8_t min_ch; 
uint8_t max_ch;
uint8_t dsch_rate; 


volatile uint8_t dummy;

void mode0(void);
void blue (void);
void mode1(void);
void red(void);
void modeBGRY(void);
void green(void);
void mode3(void);
void white(void);
void yellow(void);
void mode4(void);
void mode5(void);

void conversion (uint16_t *, uint8_t *);
void do_output(uint8_t *, uint8_t *);
uint8_t autoGainControl(uint8_t *data, uint8_t num);

//;TimeKey:.byte	1       ;����� ������� ������
//Pause:	.byte	1       ;����� �� ���������� ������� ������
//;NumProg:.byte	1       ;����� ��������� 
//Spoint:	.byte 	1       ;��������� ����� ���
//ARU:    .byte	1		;����� ���
//;Mtime:  .byte   1       ;����� �� ����� ������
//tick:   .byte   2

const uint16_t logs[]  PROGMEM = {   \
                                     24, 30, 37, 47, 58, 72, 89, 111,
                                     138, 171, 213, 264, 328, 407, 505, 627,
                                     778, 966, 1199, 1488, 1846, 2292, 2844, 3529,
                                     4380, 5436, 6746, 8371, 10389, 12892, 16000, 0xFFFF};




void hw_init(void)
{
	cli();
	/* GPIO config */
	DDRB = C3G_PB | C3R_PB  | PWM_PB | LED_PB | B4_FREE_PB | B5_FREE_PB;
	PORTC |= MODE_PC; // button pull-up
	DDRC |= C2B_PC | C2R_PC | C2G_PC | C3B_PC;
	DDRD = C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD | D0_FREE_PD | D1_FREE_PD;

	PORTB &= ~(C3G_PB | C3R_PB | PWM_PB);
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);

//  wgm13-10: 0101 - mode????
//  Timer 1 initialization. Timer 1 is used for AutoLevel feedback PWD
	TCCR1A = 1<<COM1A1 | 1<<COM1A0 | 1<<WGM10; //0b11000001	// com1a =11  wgm11:10 = fast PWM 8bit 
	TCCR1B = 1<<WGM12 | 1<<CS10; //0b00001001	// WGM13:12= fast PWM 8bit,  CS1[2:0]= clk ;

//  Start A/D with ch1, free running 19.5 kbps (52uS) at 8 ��� 8000000/32 = 4uS. ADC cycle = 13 * 4uS = 52

	ADMUX = 1<<ADLAR | 1<<MUX0; //0b00100001 ; ADLAR=1, MUX[3:0]=0001  1� ����� ADC
	ADCSR = 1<<ADEN | 1<<ADSC | 1<<ADFR| 1<<ADIE | 1<<ADPS2 | 1<<ADPS1; //0b1110 1101 ADEN=1,ADSC=1,ADFR=1,ADIE=1,ADPS[2:0]=110 (for 8Mhz was 101)
    OCR1AH = 0;
    OCR1AL = 0x80;
  
//   Timer 0 init, used for LED PWD  , 32uS 
    TCNT0 = 0x00;
    TIMSK |= 1<<TOIE0; //Interrupt enable
    TCCR0 = 1<<CS02;   //F = CLK/8 -> 16000000/8 = 2000000Mhz // 16000000/256 = 62500
 
//  Timer 2 init, system ticks 1mS
    TCNT2 = 0;
    TIMSK |= 1<<TOIE2; //Interrupt enable
    TCCR2 = 0x7; // F = CLK/1024

    MCUCR = 0; //external interrupts disable, sleep off
// initialize the UART (serial port)

#ifdef debug
	uartInit();
// set the baud rate of the UART for our debug/reporting output
	uartSetBaudRate(57600);
    rprintfInit(uartSendByte);
	// initialize vt100 library
//vt100Init();
	// clear the terminal screen
//	vt100ClearScreen();
#endif



    // enable interrupts
    sei();

}



int main(void)
{
    uint8_t i;
//    uint8_t j, m;

    tick = 0;
    samplesIndex = 0;
    pwmpoint = 0x00; // set initial pwm step - first bit

    mode = 0; // start from mode 0
    min_ch = 3;
    max_ch = 6; 
    dsch_rate = 1;
    mode = 0;
    pause_cnt=0;
    pause = 0;
    white_point = 0;

    aru = 0x80;
    dsch_rate = 2;

    for (i=0; i< CHANNEL_MAX; i++)
    {
        levels[i] = 0x00;
    }

    for (i=0; i< OUTPUT_MAX; i++)
    {
        pwm_output[i] = 0x00;
    }

    for (i=0; i< OUTPUT_MAX; i++)
    {
        output_buff[i] = 0x00;
    }


	hw_init();

    flags = 1<<ADC_CYCLE;   // Clear flags and start wave form capturing

#ifdef debug
    rprintf("\r\nDisco Light v2.0\r\n");
#endif


    while(1)
    { 
        while(flags & (1<<ADC_CYCLE))
        {

            // do something usefull while waiting for ADC
            dummy++;
              
        }

    	fft_input(mem.samples, mem.bfly_buff); //520uS

        flags |= 1<<ADC_CYCLE; //let ADC go

	    fft_execute(mem.bfly_buff); // 7.5mS

//        PORTD |= D1_FREE_PD;
		fft_output(mem.bfly_buff, mem.spectrum); // reuse samples buff // 3.8mS
//        PORTD &= ~D1_FREE_PD;

        conversion(mem.spectrum, levels);

    }

	return 0;
}



void conversion(uint16_t *buff, uint8_t *levels)
{
    uint16_t log;
    uint8_t n;
    uint8_t value;

    /* spectrum is array of 16 uint16 values, map them to 12 output channels */


    for(n = 0; n < (CHANNEL_MAX); n++)
    {
        value = 0;

        log = pgm_read_word(&logs[value]);


        while(buff[n] > log)
        {
            value++;
            log = pgm_read_word(&logs[value]);
        }

        /* m = 0...31  */

        if (levels[n] <= 1)
            levels[n] = 0; 
        else
            levels[n] -= 1;             

        if(value > levels[n])
            levels[n] = 0x1C&value;
    }
}

uint8_t autoGainControl(uint8_t *data, uint8_t num)
{
    uint8_t n;
    uint8_t channels_on;

    channels_on = 0;

    for (n=0;n<(num);n++)
    {
        if(data[n] > 8)
        {
            channels_on++;
        }
     
    }
// max_ch min_ch
    if(channels_on > max_ch)
    {
        if(aru != 1)
            aru--;
    }
    else if(channels_on < min_ch)
    {
        if(aru < 222)
            aru++;
    }

    OCR1AL = aru;

    /* pause detection */

    if(aru == 222 && channels_on < min_ch)
        return 1;
    else
        return 0;

}


uint8_t mapping[]={2, 3, 4, 6, 7, 8, 10, 11, 12, 13, 14, 15};

void makeoutput0(uint8_t *input, uint8_t *output, uint8_t num)
{
    uint8_t n, m;
        for (n=0;n<num;n++)
        {
            m = mapping[n];
            if(output[n] >= input[m])
            {
                /* slow discharge */
                if(output[n] < dsch_rate)
                    output[n] = 0;
                else
                    output[n] = output[n] - dsch_rate;
            }
            else
            {
                output[n] = 8*input[m];        
            }
//            pwm_output[n] = output[n];
        }
}

void makeoutput1(uint8_t *input, uint8_t *output, uint8_t num)
{
    uint8_t n, m;
        for (n=0;n<num;n++)
        {
            m = mapping[n];
            if(output[n] >= 8*input[m])
            {
                /* slow discharge */
                if(output[n] < dsch_rate)
                    output[n] = 0;
                else
                    output[n] = output[n] - dsch_rate;
            }
            else
            {
                output[n] = 8*input[m];        
            }

//            pwm_output[n] = output[n];
        }
}

// 1mS ticks
ISR(TIMER2_OVF_vect)
{
    uint8_t button;
    uint8_t n;

    TCNT2 = (0xFF - 0x0F); // ~1mS: 16000000/(1024*15)
    tick++;

    button = PINC;
    
    if (button&MODE_PC)
    {
        if(flags&(1<<MODE_INPUT)) // was button dpressed after last press?
            {
                mode++;
                switch(mode)
                {
                    case 0x00:
                        min_ch = 3;
                        max_ch = 6; 
                        dsch_rate = 1;
                        mode = 0;
                        break;
                    case 0x01:
                        break;
                    case 0x02:
                        min_ch = 4;
                        max_ch = 8; 
                        dsch_rate = 8;
                        break;
                    case 0x03:
                        break;
                    case 0x04:
                        min_ch = 4;
                        max_ch = 8; 
                        dsch_rate = 4;
                        break;
                    case 0x05:
                        break;
                    case 0x06:
                        min_ch = 6;
                        max_ch = 10; 
                        dsch_rate = 4;
                        break;
                    case 0x07:
                        break;
                    case 0x08:
                        break;
                    default:
                        min_ch = 3;
                        max_ch = 6; 
                        dsch_rate = 1;
                        mode = 0; 
                        break;
                }
                flags&=~(1<<MODE_INPUT); // request the button to be released before we register new button press
            }
    }
    else
    {

        flags|=1<<MODE_INPUT; // button was released
    }


    if(!(tick%1000))
    {
        if(PINB & LED_PB)
        {
            PORTB &= ~LED_PB;
        }
        else
        {
            PORTB |= LED_PB;
        }

    }

    if(!(tick%50))
    {

        if (autoGainControl(output_buff, OUTPUT_MAX))
        {

            if(pause_cnt < 255)
                pause_cnt++;
        }
        else
        {
            if(pause_cnt)
            {
                pause_cnt--;
            }
            else
                pause_cnt=0;
        }

        if(pause_cnt > 2)
        {
            PORTD |= D0_FREE_PD;
            pause = 1;
        }
        else
        {
            PORTD &= ~D0_FREE_PD;
            pause = 0;
            white_point = 0;
        }

        switch(mode)
        {
            case 0x00:
            case 0x02:
                makeoutput0(levels, output_buff, OUTPUT_MAX);
                break;
            case 0x04:
            case 0x06:
                makeoutput1(levels, output_buff, OUTPUT_MAX);
                break;
            default:
                break;
        }

        if(!pause)
        {
            for (n=0;n<OUTPUT_MAX;n++)
            {
                pwm_output[n] = output_buff[n];
            }
        }

    }

    if(pause)
    {
        if(white_point<255)
            white_point++;

        for (n=0;n<OUTPUT_MAX;n++)
        {
            pwm_output[n] = white_point;
        }
    }

}

/* LED PWM ISR */
ISR(TIMER0_OVF_vect)
{
// Binary Angle Modulation, refer to http://bsvi.ru/bam-alternativa-shimu/

    TCNT0 = (0xFF - 2*(1<<pwmpoint)) + 1 ; //restart the timer, 0x100-0xC0 = 0x40 (64), divider 64. 2Mhz-> 500nS; 500nS*64 = 32uS. 32uS*256steps = 122Hz PWM */

    if(pause) // special mode for pause
    {
    }

    /* we can have quite a few indication modes */
    switch(mode)
    {
        case 0x00:
            mode0(); // fast 0
            break;
        case 0x01:
            blue();
            break;
        case 0x02:
            mode0(); // slow 0
            break;
        case 0x03:
            red();
            break;
        case 0x04:
            mode0(); // fast 1
            break;
        case 0x05:
            green();
            break;
        case 0x06:
            modeBGRY(); // Blue Green Red Yellow
            break;
        case 0x07:
            yellow();
            break;
        case 0x08:
            white();
            break;
        default:
            mode = 0; 
            break;
    }

    pwmpoint++;
    if(pwmpoint == 8)
        pwmpoint = 0;
}


void mode0()
{
    uint8_t mask;

    uint8_t temp_B = 0;
    uint8_t temp_C = 0;
    uint8_t temp_D = 0;

    mask = 1 << pwmpoint;

    if (mask & pwm_output[0])
        temp_D |= C1G_PD;
    if (mask & pwm_output[1])
        temp_D |= C1R_PD;
    if (mask & pwm_output[2])
        temp_D |= C1B_PD;
    if (mask & pwm_output[3])
        temp_C |= C2G_PC;
    if (mask & pwm_output[4])
        temp_C |= C2R_PC;
    if (mask & pwm_output[5])
        temp_C |= C2B_PC;
    if (mask & pwm_output[6])
        temp_B |= C3G_PB;
    if (mask & pwm_output[7])
        temp_B |= C3R_PB;
    if (mask & pwm_output[8])
        temp_C |= C3B_PC;
    if (mask & pwm_output[9])
        temp_D |= C4G_PD;
    if (mask & pwm_output[10])
        temp_D |= C4R_PD;
    if (mask & pwm_output[11])
        temp_D |= C4B_PD;

	PORTB &= ~(C3G_PB | C3R_PB);
    PORTB |= temp_B;
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
    PORTC |= temp_C;
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);
    PORTD |= temp_D;

    return;
}


void modeBGRY()
{
    uint8_t mask;

    uint8_t temp_B = 0;
    uint8_t temp_C = 0;
    uint8_t temp_D = 0;

    mask = 1 << pwmpoint;

    if (mask & pwm_output[3])
        temp_D |= C1B_PD;
    if (mask & pwm_output[6])
        temp_C |= C2G_PC;
    if (mask & pwm_output[8])
        temp_B |= C3R_PB;
    if (mask & pwm_output[10])
        temp_D |= C4G_PD;
    if (mask & pwm_output[10])
        temp_D |= C4R_PD;


	PORTB &= ~(C3G_PB | C3R_PB);
    PORTB |= temp_B;
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
    PORTC |= temp_C;
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);
    PORTD |= temp_D;

    return;
}


void blue(void)
{
/* blue only */
	PORTB &= ~(C3G_PB | C3R_PB);
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);

//    PORTB |= C3B_PB;
    PORTC |= C2B_PC | C3B_PC;
    PORTD |= C1B_PD | C4B_PD;

}

void red(void)
{
/* red only */
	PORTB &= ~(C3G_PB | C3R_PB);
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);

    PORTB |= C3R_PB;
    PORTC |= C2R_PC;
    PORTD |= C1R_PD | C4R_PD;


}

void green(void)
{
/* green only */
	PORTB &= ~(C3G_PB | C3R_PB);
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);

    PORTB |= C3G_PB;
    PORTC |= C2G_PC;
    PORTD |= C1G_PD | C4G_PD;
}

void white(void)
{
/* white*/
	PORTB |= (C3G_PB | C3R_PB);
	PORTC |= (C2B_PC | C2R_PC | C2G_PC | C3B_PC);
   	PORTD |= (C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);
}

void yellow(void)
{
/* green + red */
	PORTB &= ~(C3G_PB | C3R_PB);
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);


    PORTB |= C3G_PB | C3R_PB;
    PORTC |= C2G_PC | C2R_PC;
    PORTD |= C1G_PD | C4G_PD | C1R_PD | C4R_PD;

}



void mode5(void)
{
	PORTB &= ~(C3G_PB | C3R_PB);
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);
}


void mode6(void)
{
	PORTB &= ~(C3G_PB | C3R_PB);
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);
}


void mode7(void)
{
	PORTB &= ~(C3G_PB | C3R_PB);
	PORTC &= ~(C2B_PC | C2R_PC | C2G_PC | C3B_PC);
   	PORTD &= ~(C1G_PD | C1R_PD | C1B_PD | C4G_PD | C4R_PD | C4B_PD);
}

ISR(ADC_vect)
{
    if(flags&(1<<ADC_CYCLE)) /*skip if the flag is not set */
    {

#if 0
        if(PINB & B6_FREE_PB)
        {
            PORTB &= ~B6_FREE_PB;
        }
        else
        {
            PORTB |= B6_FREE_PB;
        }
#endif
        mem.samples[samplesIndex] = ADC - 0x8000;
        samplesIndex++;
        if (samplesIndex >=FFT_N)
        {
            samplesIndex = 0;
            flags &=~(1<<ADC_CYCLE);
        }
     }

    return;
}





