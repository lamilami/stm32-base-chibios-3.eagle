AVR Studio project
\default\dl-2011.hex - output file for programmer