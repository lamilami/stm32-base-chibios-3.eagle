discolight.sch - schematic in PCAD-2006 SP1 format
discolight.net - netlist
discolight-[SheetX].pdf - schematic in PDF format
